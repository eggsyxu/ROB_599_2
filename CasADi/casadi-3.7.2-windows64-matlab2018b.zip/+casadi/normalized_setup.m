function varargout = normalized_setup(varargin)
    %NORMALIZED_SETUP [INTERNAL] 
    %
    %  std::ostream & = NORMALIZED_SETUP()
    %  NORMALIZED_SETUP(std::istream & stream)
    %
    %
  [varargout{1:nargout}] = casadiMEX(45, varargin{:});
end
