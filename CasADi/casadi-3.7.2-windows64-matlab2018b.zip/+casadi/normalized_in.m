function varargout = normalized_in(varargin)
    %NORMALIZED_IN [INTERNAL] 
    %
    %  int = NORMALIZED_IN(std::istream & stream, double & ret)
    %
    %
  [varargout{1:nargout}] = casadiMEX(49, varargin{:});
end
